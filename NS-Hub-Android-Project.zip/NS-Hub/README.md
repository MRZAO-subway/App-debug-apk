# NS Hub — Android

Aplicativo Android nativo em Kotlin, com interface preto e roxo.

## Requisitos
- Android Studio Ladybug ou mais recente
- JDK 17
- Android SDK Platform 35
- Gradle gerenciado pelo Android Studio

## Gerar o APK
1. Extraia o ZIP.
2. Abra a pasta `NS-Hub` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Recursos
- Painel inicial NS Hub
- Treino de toque com contador
- Calculadora de sensibilidade
- Guia de desempenho Android
- Layout escuro com detalhes roxos

O app é um companion independente. Não modifica o cliente Roblox nem interfere em partidas.
