package com.nshub.roblox

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 8, 18)
    private val panel = Color.rgb(25, 19, 39)
    private val purple = Color.rgb(160, 96, 255)
    private val white = Color.rgb(245, 240, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(1, Color.rgb(65, 48, 91))
        }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun base(title: String, subtitle: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
        }
        scroll.addView(content)
        setContentView(scroll)

        content.addView(text("NS HUB", 13f, purple, true))
        content.addView(text(title, 29f, white, true).apply {
            setPadding(0, 8, 0, 4)
        })
        content.addView(text(subtitle, 14f, Color.LTGRAY))
        content.addView(space(20))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun card(title: String, description: String, action: String, onClick: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(17, 16, 17, 16)
            background = rounded(panel)
        }
        box.addView(text(title, 18f, white, true))
        box.addView(text(description, 13f, Color.LTGRAY).apply {
            setPadding(0, 7, 0, 14)
        })
        val button = Button(this).apply {
            text = action
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(purple, 16f)
            setOnClickListener { onClick() }
        }
        box.addView(button)
        content.addView(box)
        content.addView(space(13))
    }

    private fun showHome() {
        base("Painel de ferramentas", "Companion hub • Roblox")
        card("Treino de mira", "Pratique precisão e tempo de reação em um treino independente.", "Abrir treino") {
            showAimTrainer()
        }
        card("Calculadora de sensibilidade", "Converta e registre sua sensibilidade preferida.", "Abrir calculadora") {
            showSensitivity()
        }
        card("Guia de desempenho", "Ajustes legítimos para melhorar a experiência no Android.", "Ver dicas") {
            showPerformance()
        }
        card("Sobre o NS Hub", "Ferramentas auxiliares que não alteram o cliente nem interferem em partidas.", "Sobre") {
            showAbout()
        }
        content.addView(text("NS Hub • v1.0 • Preto & roxo", 12f, Color.GRAY))
    }

    private fun header(title: String, subtitle: String) {
        base(title, subtitle)
        val back = Button(this).apply {
            text = "← Voltar"
            isAllCaps = false
            setTextColor(white)
            background = rounded(Color.rgb(48, 34, 68))
            setOnClickListener { showHome() }
        }
        content.addView(back)
        content.addView(space(16))
    }

    private fun showAimTrainer() {
        header("Treino de mira", "Exercício simples de precisão — fora do Roblox")
        val target = Button(this).apply {
            text = "TOQUE AQUI"
            textSize = 20f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(purple, 100f)
            layoutParams = LinearLayout.LayoutParams(230, 230).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = 28
                bottomMargin = 20
            }
        }
        var hits = 0
        val score = text("Acertos: 0", 18f, white, true)
        target.setOnClickListener {
            hits++
            score.text = "Acertos: $hits"
            target.text = if (hits % 2 == 0) "BOA!" else "ACERTO!"
        }
        content.addView(score)
        content.addView(target)
        content.addView(text("Faça 30 toques controlados. Priorize precisão antes de velocidade.", 14f, Color.LTGRAY))
        content.addView(space(12))
        val reset = Button(this).apply {
            text = "Zerar pontuação"
            isAllCaps = false
            setOnClickListener { hits = 0; score.text = "Acertos: 0"; target.text = "TOQUE AQUI" }
        }
        content.addView(reset)
    }

    private fun showSensitivity() {
        header("Sensibilidade", "Anote e compare suas configurações")
        val input = EditText(this).apply {
            hint = "Sensibilidade atual (0–100)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(white)
            setHintTextColor(Color.GRAY)
            setPadding(14, 12, 14, 12)
            background = rounded(panel)
        }
        val multiplier = EditText(this).apply {
            hint = "Novo multiplicador (ex.: 1.2)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(white)
            setHintTextColor(Color.GRAY)
            setPadding(14, 12, 14, 12)
            background = rounded(panel)
        }
        val result = text("Resultado: —", 18f, purple, true)
        content.addView(input); content.addView(space(10))
        content.addView(multiplier); content.addView(space(12))
        content.addView(Button(this).apply {
            text = "Calcular"
            isAllCaps = false
            setOnClickListener {
                val baseValue = input.text.toString().toDoubleOrNull()
                val factor = multiplier.text.toString().toDoubleOrNull()
                result.text = if (baseValue != null && factor != null && baseValue in 0.0..100.0 && factor in 0.1..5.0) {
                    "Resultado: ${"%.2f".format(baseValue * factor)}"
                } else "Informe sensibilidade 0–100 e multiplicador 0,1–5."
            }
        })
        content.addView(space(16)); content.addView(result)
        content.addView(space(10))
        content.addView(text("A calculadora não muda configurações dentro do Roblox. Aplique o valor manualmente quando o jogo permitir.", 13f, Color.LTGRAY))
    }

    private fun showPerformance() {
        header("Guia de desempenho", "Ajustes comuns no Android")
        val tips = listOf(
            "Feche apps em segundo plano antes de jogar.",
            "Ative o modo de desempenho do aparelho, se disponível.",
            "Reduza gráficos dentro das opções do próprio jogo.",
            "Mantenha o Android e o Roblox atualizados.",
            "Evite jogar enquanto o aparelho estiver superaquecido.",
            "Use uma conexão Wi‑Fi estável e fique próximo ao roteador."
        )
        tips.forEachIndexed { index, tip ->
            content.addView(text("${index + 1}. $tip", 15f).apply { setPadding(0, 8, 0, 8) })
        }
    }

    private fun showAbout() {
        header("Sobre", "NS Hub • versão 1.0")
        content.addView(text(
            "O NS Hub reúne ferramentas auxiliares: treino de toque, calculadora de sensibilidade e dicas de desempenho. Ele não injeta código, não lê a memória do Roblox e não automatiza ações em partidas.",
            15f, Color.LTGRAY
        ))
    }
}
